package com.example.orderapp.context;

import android.app.Application;

import com.example.orderapp.bean.UserBean;


public class AppContext extends Application {
        private UserBean userBean;

        public UserBean getUserBean() {
            return userBean;
        }
        public void setUserBean(UserBean userBean) {
            this.userBean = userBean;

        }

    }
