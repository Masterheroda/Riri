package com.example.orderapp.Database;

        import android.content.Context;
        import android.database.Cursor;
        import android.database.sqlite.SQLiteDatabase;
        import android.database.sqlite.SQLiteOpenHelper;
        import android.util.Log;

        import com.example.orderapp.bean.UserBean;

        import java.util.ArrayList;

public class DdAdapter extends SQLiteOpenHelper {






    private static final int DATABASE_VERSION = 1;


    private static final String DATABASE_NAME = "User";

    private static final String USER_INFO_TABLE = "user_table";

    // Contacts Table Columns names
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_FIRSTNAME = "user_firstname";
    private static final String KEY_USER_LASTNAME = "user_Lastname";
    private static final String KEY_USER_MO_NO = "user_mobilenumber";
    private static final String KEY_USER_ADDRESS = "user_address";
    private static final String KEY_USER_USERNAME = "user_username";
    private static final String KEY_USER_PASSWORD = "user_password";

    public DdAdapter(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override

    public void onCreate(SQLiteDatabase db) {
        String queryUser="CREATE TABLE "+ USER_INFO_TABLE +" (" +
                KEY_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                KEY_USER_FIRSTNAME + " TEXT, " +
                KEY_USER_LASTNAME + " TEXT, " +
                KEY_USER_MO_NO + " TEXT, " +
                KEY_USER_ADDRESS + " TEXT," +
                KEY_USER_USERNAME + " TEXT," +
                KEY_USER_PASSWORD + " TEXT " + ")";
        Log.d("queryUser",queryUser);

        try
        {
            db.execSQL(queryUser);

        }
        catch (Exception e) {
            e.printStackTrace();
            Log.e("Exception", e.getMessage());
        }

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
        String queryUser="CREATE TABLE "+ USER_INFO_TABLE +" (" +
                KEY_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                KEY_USER_FIRSTNAME + " TEXT, " +
                KEY_USER_LASTNAME + " TEXT, " +
                KEY_USER_MO_NO + " TEXT, " +
                KEY_USER_ADDRESS + " TEXT," +
                KEY_USER_USERNAME + " TEXT," +
                KEY_USER_PASSWORD + " TEXT " + ")";
        Log.d("queryUser",queryUser);



        try
        {
            db.execSQL(queryUser);
        }
        catch (Exception e) {
            e.printStackTrace();
            Log.e("Exception", e.getMessage());
        }
    }

    public void addUser(UserBean userBean) {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "INSERT INTO user_table (user_firstname,user_Lastname,user_mobilenumber,user_address,user_username,user_password) values ('"+
                userBean.getUser_firstname()+"', '"+
                userBean.getUser_lastname()+"', '"+
                userBean.getUser_mobilenumber()+"', '"+
                userBean.getUser_address()+"', '"+
                userBean.getUser_username()+"', '"+
                userBean.getUser_password()+"')";


        Log.d("query", query);
        db.execSQL(query);
        db.close();
    }

    public UserBean validateUser(String userName, String password)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM user_table where user_username='"+userName+"' and user_password='"+password+"'";
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst())
        {

            UserBean userBean = new UserBean();
            userBean.getUser_id(Integer.parseInt(cursor.getString(0)));
            userBean.setUser_firstname(cursor.getString(1));
            userBean.setUser_lastname(cursor.getString(2));
            userBean.setUser_mobilenumber(cursor.getString(3));
            userBean.setUser_address(cursor.getString(4));
            userBean.setUser_username(cursor.getString(5));
            userBean.setUser_password(cursor.getString(6));
            return userBean;
        }
        return null;
    }

    public ArrayList<UserBean> getAllUser()
    {
        Log.d("in get all","in get all" );
        ArrayList<UserBean> list = new ArrayList<UserBean>();

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM User_table";
        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst())
        {
            do{
                UserBean userBean = new UserBean();
                userBean.setUser_id(Integer.parseInt(cursor.getString(0)));
                userBean.setUser_firstname(cursor.getString(1));
                userBean.setUser_lastname(cursor.getString(2));
                userBean.setUser_mobilenumber(cursor.getString(3));
                userBean.setUser_address(cursor.getString(4));
                userBean.setUser_username(cursor.getString(5));
                userBean.setUser_password(cursor.getString(6));
                list.add(userBean);

            }while(cursor.moveToNext());
        }
        return list;
    }

    public void deleteUser(int Userid) {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "DELETE FROM user_table WHERE user_id="+Userid ;

        Log.d("query", query);
        db.execSQL(query);
        db.close();
    }
}

