package com.example.orderapp.bean;

public class UserBean {


        private int user_id;
        private String user_firstname;
        private String user_lastname;
        private String user_mobilenumber;
        private String user_address;
        private String user_username;
        private String user_password;
        public int getUser_id(int i) {
            return user_id;
        }
        public void setUser_id(int user_id) {
            this.user_id = user_id;
        }
        public String getUser_firstname() {
            return user_firstname;
        }
        public void setUser_firstname(String user_firstname) {
            this.user_firstname = user_firstname;
        }
        public String getUser_lastname() {
            return user_lastname;
        }
        public void setUser_lastname(String user_lastname) {
            this.user_lastname = user_lastname;
        }
        public String getUser_mobilenumber() {
            return user_mobilenumber;
        }
        public void setUser_mobilenumber(String user_mobilenumber) {
            this.user_mobilenumber = user_mobilenumber;
        }
        public String getUser_address() {
            return user_address;
        }
        public void setUser_address(String user_address) {
            this.user_address = user_address;
        }
        public String getUser_username() {
            return user_username;
        }
        public void setUser_username(String user_username) {
            this.user_username = user_username;
        }
        public String getUser_password() {
            return user_password;
        }
        public void setUser_password(String user_password) {
            this.user_password = user_password;
        }




    }


